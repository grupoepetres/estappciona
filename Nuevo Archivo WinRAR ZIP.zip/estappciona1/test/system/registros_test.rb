require "application_system_test_case"

class RegistrosTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit registros_url
  #
  #   assert_selector "h1", text: "Registro"
  # end
end
