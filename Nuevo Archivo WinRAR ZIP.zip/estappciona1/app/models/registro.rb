class Registro < ApplicationRecord
end
